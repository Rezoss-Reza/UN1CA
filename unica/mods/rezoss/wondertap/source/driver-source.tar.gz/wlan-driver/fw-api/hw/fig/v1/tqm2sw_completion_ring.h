/*
 * Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
 * SPDX-License-Identifier: ISC
 */

#ifndef _TQM2SW_COMPLETION_RING_H_
#define _TQM2SW_COMPLETION_RING_H_

#include "tx_rate_stats_info.h"
#include "buffer_addr_info.h"
#define NUM_OF_DWORDS_TQM2SW_COMPLETION_RING 8

struct tqm2sw_completion_ring {
#ifndef WIFI_BIT_ORDER_BIG_ENDIAN
             struct   buffer_addr_info                                          buf_or_desc_virt_addr_or_addr_info;
             uint32_t release_source_module                                   :  3,
                      cache_id                                                :  1,
                      reserved_2a                                             :  2,
                      buffer_or_desc_type                                     :  3,
                      return_buffer_manager                                   :  4,
                      tqm_release_reason                                      :  4,
                      rbm_override_valid                                      :  1,
                      sw_buffer_cookie_11_0                                   : 12,
                      cookie_conversion_status                                :  1,
                      tqm_completion_error                                    :  1;
             uint32_t tqm_status_number                                       : 24,
                      transmit_count                                          :  7,
                      sw_release_details_valid                                :  1;
             uint32_t ack_frame_rssi                                          :  8,
                      first_msdu                                              :  1,
                      last_msdu                                               :  1,
                      fw_tx_notify_frame                                      :  3,
                      buffer_timestamp                                        : 19;
             struct   tx_rate_stats_info                                        tx_rate_stats;
             uint32_t sw_peer_id                                              : 16,
                      tid                                                     :  4,
                      sw_buffer_cookie_19_12                                  :  8,
                      looping_count                                           :  4;
#else
             struct   buffer_addr_info                                          buf_or_desc_virt_addr_or_addr_info;
             uint32_t tqm_completion_error                                    :  1,
                      cookie_conversion_status                                :  1,
                      sw_buffer_cookie_11_0                                   : 12,
                      rbm_override_valid                                      :  1,
                      tqm_release_reason                                      :  4,
                      return_buffer_manager                                   :  4,
                      buffer_or_desc_type                                     :  3,
                      reserved_2a                                             :  2,
                      cache_id                                                :  1,
                      release_source_module                                   :  3;
             uint32_t sw_release_details_valid                                :  1,
                      transmit_count                                          :  7,
                      tqm_status_number                                       : 24;
             uint32_t buffer_timestamp                                        : 19,
                      fw_tx_notify_frame                                      :  3,
                      last_msdu                                               :  1,
                      first_msdu                                              :  1,
                      ack_frame_rssi                                          :  8;
             struct   tx_rate_stats_info                                        tx_rate_stats;
             uint32_t looping_count                                           :  4,
                      sw_buffer_cookie_19_12                                  :  8,
                      tid                                                     :  4,
                      sw_peer_id                                              : 16;
#endif
};

#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_BUFFER_ADDR_31_0_OFFSET 0x00000000
#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_BUFFER_ADDR_31_0_LSB 0
#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_BUFFER_ADDR_31_0_MSB 31
#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_BUFFER_ADDR_31_0_MASK 0xffffffff

#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_BUFFER_ADDR_39_32_OFFSET 0x00000004
#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_BUFFER_ADDR_39_32_LSB 0
#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_BUFFER_ADDR_39_32_MSB 7
#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_BUFFER_ADDR_39_32_MASK 0x000000ff

#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_RETURN_BUFFER_MANAGER_OFFSET 0x00000004
#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_RETURN_BUFFER_MANAGER_LSB 8
#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_RETURN_BUFFER_MANAGER_MSB 11
#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_RETURN_BUFFER_MANAGER_MASK 0x00000f00

#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_SW_BUFFER_COOKIE_OFFSET 0x00000004
#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_SW_BUFFER_COOKIE_LSB 12
#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_SW_BUFFER_COOKIE_MSB 31
#define TQM2SW_COMPLETION_RING_BUF_OR_DESC_VIRT_ADDR_OR_ADDR_INFO_SW_BUFFER_COOKIE_MASK 0xfffff000

#define TQM2SW_COMPLETION_RING_RELEASE_SOURCE_MODULE_OFFSET                         0x00000008
#define TQM2SW_COMPLETION_RING_RELEASE_SOURCE_MODULE_LSB                            0
#define TQM2SW_COMPLETION_RING_RELEASE_SOURCE_MODULE_MSB                            2
#define TQM2SW_COMPLETION_RING_RELEASE_SOURCE_MODULE_MASK                           0x00000007

#define TQM2SW_COMPLETION_RING_CACHE_ID_OFFSET                                      0x00000008
#define TQM2SW_COMPLETION_RING_CACHE_ID_LSB                                         3
#define TQM2SW_COMPLETION_RING_CACHE_ID_MSB                                         3
#define TQM2SW_COMPLETION_RING_CACHE_ID_MASK                                        0x00000008

#define TQM2SW_COMPLETION_RING_RESERVED_2A_OFFSET                                   0x00000008
#define TQM2SW_COMPLETION_RING_RESERVED_2A_LSB                                      4
#define TQM2SW_COMPLETION_RING_RESERVED_2A_MSB                                      5
#define TQM2SW_COMPLETION_RING_RESERVED_2A_MASK                                     0x00000030

#define TQM2SW_COMPLETION_RING_BUFFER_OR_DESC_TYPE_OFFSET                           0x00000008
#define TQM2SW_COMPLETION_RING_BUFFER_OR_DESC_TYPE_LSB                              6
#define TQM2SW_COMPLETION_RING_BUFFER_OR_DESC_TYPE_MSB                              8
#define TQM2SW_COMPLETION_RING_BUFFER_OR_DESC_TYPE_MASK                             0x000001c0

#define TQM2SW_COMPLETION_RING_RETURN_BUFFER_MANAGER_OFFSET                         0x00000008
#define TQM2SW_COMPLETION_RING_RETURN_BUFFER_MANAGER_LSB                            9
#define TQM2SW_COMPLETION_RING_RETURN_BUFFER_MANAGER_MSB                            12
#define TQM2SW_COMPLETION_RING_RETURN_BUFFER_MANAGER_MASK                           0x00001e00

#define TQM2SW_COMPLETION_RING_TQM_RELEASE_REASON_OFFSET                            0x00000008
#define TQM2SW_COMPLETION_RING_TQM_RELEASE_REASON_LSB                               13
#define TQM2SW_COMPLETION_RING_TQM_RELEASE_REASON_MSB                               16
#define TQM2SW_COMPLETION_RING_TQM_RELEASE_REASON_MASK                              0x0001e000

#define TQM2SW_COMPLETION_RING_RBM_OVERRIDE_VALID_OFFSET                            0x00000008
#define TQM2SW_COMPLETION_RING_RBM_OVERRIDE_VALID_LSB                               17
#define TQM2SW_COMPLETION_RING_RBM_OVERRIDE_VALID_MSB                               17
#define TQM2SW_COMPLETION_RING_RBM_OVERRIDE_VALID_MASK                              0x00020000

#define TQM2SW_COMPLETION_RING_SW_BUFFER_COOKIE_11_0_OFFSET                         0x00000008
#define TQM2SW_COMPLETION_RING_SW_BUFFER_COOKIE_11_0_LSB                            18
#define TQM2SW_COMPLETION_RING_SW_BUFFER_COOKIE_11_0_MSB                            29
#define TQM2SW_COMPLETION_RING_SW_BUFFER_COOKIE_11_0_MASK                           0x3ffc0000

#define TQM2SW_COMPLETION_RING_COOKIE_CONVERSION_STATUS_OFFSET                      0x00000008
#define TQM2SW_COMPLETION_RING_COOKIE_CONVERSION_STATUS_LSB                         30
#define TQM2SW_COMPLETION_RING_COOKIE_CONVERSION_STATUS_MSB                         30
#define TQM2SW_COMPLETION_RING_COOKIE_CONVERSION_STATUS_MASK                        0x40000000

#define TQM2SW_COMPLETION_RING_TQM_COMPLETION_ERROR_OFFSET                          0x00000008
#define TQM2SW_COMPLETION_RING_TQM_COMPLETION_ERROR_LSB                             31
#define TQM2SW_COMPLETION_RING_TQM_COMPLETION_ERROR_MSB                             31
#define TQM2SW_COMPLETION_RING_TQM_COMPLETION_ERROR_MASK                            0x80000000

#define TQM2SW_COMPLETION_RING_TQM_STATUS_NUMBER_OFFSET                             0x0000000c
#define TQM2SW_COMPLETION_RING_TQM_STATUS_NUMBER_LSB                                0
#define TQM2SW_COMPLETION_RING_TQM_STATUS_NUMBER_MSB                                23
#define TQM2SW_COMPLETION_RING_TQM_STATUS_NUMBER_MASK                               0x00ffffff

#define TQM2SW_COMPLETION_RING_TRANSMIT_COUNT_OFFSET                                0x0000000c
#define TQM2SW_COMPLETION_RING_TRANSMIT_COUNT_LSB                                   24
#define TQM2SW_COMPLETION_RING_TRANSMIT_COUNT_MSB                                   30
#define TQM2SW_COMPLETION_RING_TRANSMIT_COUNT_MASK                                  0x7f000000

#define TQM2SW_COMPLETION_RING_SW_RELEASE_DETAILS_VALID_OFFSET                      0x0000000c
#define TQM2SW_COMPLETION_RING_SW_RELEASE_DETAILS_VALID_LSB                         31
#define TQM2SW_COMPLETION_RING_SW_RELEASE_DETAILS_VALID_MSB                         31
#define TQM2SW_COMPLETION_RING_SW_RELEASE_DETAILS_VALID_MASK                        0x80000000

#define TQM2SW_COMPLETION_RING_ACK_FRAME_RSSI_OFFSET                                0x00000010
#define TQM2SW_COMPLETION_RING_ACK_FRAME_RSSI_LSB                                   0
#define TQM2SW_COMPLETION_RING_ACK_FRAME_RSSI_MSB                                   7
#define TQM2SW_COMPLETION_RING_ACK_FRAME_RSSI_MASK                                  0x000000ff

#define TQM2SW_COMPLETION_RING_FIRST_MSDU_OFFSET                                    0x00000010
#define TQM2SW_COMPLETION_RING_FIRST_MSDU_LSB                                       8
#define TQM2SW_COMPLETION_RING_FIRST_MSDU_MSB                                       8
#define TQM2SW_COMPLETION_RING_FIRST_MSDU_MASK                                      0x00000100

#define TQM2SW_COMPLETION_RING_LAST_MSDU_OFFSET                                     0x00000010
#define TQM2SW_COMPLETION_RING_LAST_MSDU_LSB                                        9
#define TQM2SW_COMPLETION_RING_LAST_MSDU_MSB                                        9
#define TQM2SW_COMPLETION_RING_LAST_MSDU_MASK                                       0x00000200

#define TQM2SW_COMPLETION_RING_FW_TX_NOTIFY_FRAME_OFFSET                            0x00000010
#define TQM2SW_COMPLETION_RING_FW_TX_NOTIFY_FRAME_LSB                               10
#define TQM2SW_COMPLETION_RING_FW_TX_NOTIFY_FRAME_MSB                               12
#define TQM2SW_COMPLETION_RING_FW_TX_NOTIFY_FRAME_MASK                              0x00001c00

#define TQM2SW_COMPLETION_RING_BUFFER_TIMESTAMP_OFFSET                              0x00000010
#define TQM2SW_COMPLETION_RING_BUFFER_TIMESTAMP_LSB                                 13
#define TQM2SW_COMPLETION_RING_BUFFER_TIMESTAMP_MSB                                 31
#define TQM2SW_COMPLETION_RING_BUFFER_TIMESTAMP_MASK                                0xffffe000

#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TX_RATE_STATS_INFO_VALID_OFFSET        0x00000014
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TX_RATE_STATS_INFO_VALID_LSB           0
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TX_RATE_STATS_INFO_VALID_MSB           0
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TX_RATE_STATS_INFO_VALID_MASK          0x00000001

#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_BW_OFFSET                     0x00000014
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_BW_LSB                        1
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_BW_MSB                        3
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_BW_MASK                       0x0000000e

#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_PKT_TYPE_OFFSET               0x00000014
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_PKT_TYPE_LSB                  4
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_PKT_TYPE_MSB                  7
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_PKT_TYPE_MASK                 0x000000f0

#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_STBC_OFFSET                   0x00000014
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_STBC_LSB                      8
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_STBC_MSB                      8
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_STBC_MASK                     0x00000100

#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_LDPC_OFFSET                   0x00000014
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_LDPC_LSB                      9
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_LDPC_MSB                      9
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_LDPC_MASK                     0x00000200

#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_SGI_OFFSET                    0x00000014
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_SGI_LSB                       10
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_SGI_MSB                       11
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_SGI_MASK                      0x00000c00

#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_MCS_OFFSET                    0x00000014
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_MCS_LSB                       12
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_MCS_MSB                       16
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_MCS_MASK                      0x0001f000

#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_UNEQUAL_MODULATION_INFO_OFFSET         0x00000014
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_UNEQUAL_MODULATION_INFO_LSB            17
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_UNEQUAL_MODULATION_INFO_MSB            19
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_UNEQUAL_MODULATION_INFO_MASK           0x000e0000

#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_OFDMA_TRANSMISSION_OFFSET              0x00000014
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_OFDMA_TRANSMISSION_LSB                 20
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_OFDMA_TRANSMISSION_MSB                 20
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_OFDMA_TRANSMISSION_MASK                0x00100000

#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_RESERVED_0A_OFFSET                     0x00000014
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_RESERVED_0A_LSB                        21
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_RESERVED_0A_MSB                        24
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_RESERVED_0A_MASK                       0x01e00000

#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TONES_IN_RU_OFFSET                     0x00000014
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TONES_IN_RU_LSB                        25
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TONES_IN_RU_MSB                        28
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TONES_IN_RU_MASK                       0x1e000000

#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_NSS_OFFSET                    0x00000014
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_NSS_LSB                       29
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_NSS_MSB                       31
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_TRANSMIT_NSS_MASK                      0xe0000000

#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_PPDU_TRANSMISSION_TSF_OFFSET           0x00000018
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_PPDU_TRANSMISSION_TSF_LSB              0
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_PPDU_TRANSMISSION_TSF_MSB              31
#define TQM2SW_COMPLETION_RING_TX_RATE_STATS_PPDU_TRANSMISSION_TSF_MASK             0xffffffff

#define TQM2SW_COMPLETION_RING_SW_PEER_ID_OFFSET                                    0x0000001c
#define TQM2SW_COMPLETION_RING_SW_PEER_ID_LSB                                       0
#define TQM2SW_COMPLETION_RING_SW_PEER_ID_MSB                                       15
#define TQM2SW_COMPLETION_RING_SW_PEER_ID_MASK                                      0x0000ffff

#define TQM2SW_COMPLETION_RING_TID_OFFSET                                           0x0000001c
#define TQM2SW_COMPLETION_RING_TID_LSB                                              16
#define TQM2SW_COMPLETION_RING_TID_MSB                                              19
#define TQM2SW_COMPLETION_RING_TID_MASK                                             0x000f0000

#define TQM2SW_COMPLETION_RING_SW_BUFFER_COOKIE_19_12_OFFSET                        0x0000001c
#define TQM2SW_COMPLETION_RING_SW_BUFFER_COOKIE_19_12_LSB                           20
#define TQM2SW_COMPLETION_RING_SW_BUFFER_COOKIE_19_12_MSB                           27
#define TQM2SW_COMPLETION_RING_SW_BUFFER_COOKIE_19_12_MASK                          0x0ff00000

#define TQM2SW_COMPLETION_RING_LOOPING_COUNT_OFFSET                                 0x0000001c
#define TQM2SW_COMPLETION_RING_LOOPING_COUNT_LSB                                    28
#define TQM2SW_COMPLETION_RING_LOOPING_COUNT_MSB                                    31
#define TQM2SW_COMPLETION_RING_LOOPING_COUNT_MASK                                   0xf0000000

#endif
