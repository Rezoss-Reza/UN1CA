/*
 * Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
 * SPDX-License-Identifier: ISC
 */

#ifndef _RX_FRAME_1K_BITMAP_ACK_H_
#define _RX_FRAME_1K_BITMAP_ACK_H_

#define NUM_OF_DWORDS_RX_FRAME_1K_BITMAP_ACK 38

#define NUM_OF_QWORDS_RX_FRAME_1K_BITMAP_ACK 19

struct rx_frame_1k_bitmap_ack {
#ifndef WIFI_BIT_ORDER_BIG_ENDIAN
             uint32_t reserved_0a                                             :  5,
                      ba_bitmap_size                                          :  2,
                      gen_mlo_notification                                    :  1,
                      reserved_0b                                             :  2,
                      ba_tid                                                  :  4,
                      sta_full_aid                                            : 13,
                      reserved_0c                                             :  5;
             uint32_t mlo_sta_id                                              : 10,
                      ba_size_1024_allowed                                    :  1,
                      ba_size_512_allowed                                     :  1,
                      reserved_1a                                             : 20;
             uint32_t addr1_31_0                                              : 32;
             uint32_t addr1_47_32                                             : 16,
                      addr2_15_0                                              : 16;
             uint32_t addr2_47_16                                             : 32;
             uint32_t ba_ts_ctrl                                              : 16,
                      ba_ts_seq                                               : 16;
             uint32_t ba_ts_bitmap_31_0                                       : 32;
             uint32_t ba_ts_bitmap_63_32                                      : 32;
             uint32_t ba_ts_bitmap_95_64                                      : 32;
             uint32_t ba_ts_bitmap_127_96                                     : 32;
             uint32_t ba_ts_bitmap_159_128                                    : 32;
             uint32_t ba_ts_bitmap_191_160                                    : 32;
             uint32_t ba_ts_bitmap_223_192                                    : 32;
             uint32_t ba_ts_bitmap_255_224                                    : 32;
             uint32_t ba_ts_bitmap_287_256                                    : 32;
             uint32_t ba_ts_bitmap_319_288                                    : 32;
             uint32_t ba_ts_bitmap_351_320                                    : 32;
             uint32_t ba_ts_bitmap_383_352                                    : 32;
             uint32_t ba_ts_bitmap_415_384                                    : 32;
             uint32_t ba_ts_bitmap_447_416                                    : 32;
             uint32_t ba_ts_bitmap_479_448                                    : 32;
             uint32_t ba_ts_bitmap_511_480                                    : 32;
             uint32_t ba_ts_bitmap_543_512                                    : 32;
             uint32_t ba_ts_bitmap_575_544                                    : 32;
             uint32_t ba_ts_bitmap_607_576                                    : 32;
             uint32_t ba_ts_bitmap_639_608                                    : 32;
             uint32_t ba_ts_bitmap_671_640                                    : 32;
             uint32_t ba_ts_bitmap_703_672                                    : 32;
             uint32_t ba_ts_bitmap_735_704                                    : 32;
             uint32_t ba_ts_bitmap_767_736                                    : 32;
             uint32_t ba_ts_bitmap_799_768                                    : 32;
             uint32_t ba_ts_bitmap_831_800                                    : 32;
             uint32_t ba_ts_bitmap_863_832                                    : 32;
             uint32_t ba_ts_bitmap_895_864                                    : 32;
             uint32_t ba_ts_bitmap_927_896                                    : 32;
             uint32_t ba_ts_bitmap_959_928                                    : 32;
             uint32_t ba_ts_bitmap_991_960                                    : 32;
             uint32_t ba_ts_bitmap_1023_992                                   : 32;
#else
             uint32_t reserved_0c                                             :  5,
                      sta_full_aid                                            : 13,
                      ba_tid                                                  :  4,
                      reserved_0b                                             :  2,
                      gen_mlo_notification                                    :  1,
                      ba_bitmap_size                                          :  2,
                      reserved_0a                                             :  5;
             uint32_t reserved_1a                                             : 20,
                      ba_size_512_allowed                                     :  1,
                      ba_size_1024_allowed                                    :  1,
                      mlo_sta_id                                              : 10;
             uint32_t addr1_31_0                                              : 32;
             uint32_t addr2_15_0                                              : 16,
                      addr1_47_32                                             : 16;
             uint32_t addr2_47_16                                             : 32;
             uint32_t ba_ts_seq                                               : 16,
                      ba_ts_ctrl                                              : 16;
             uint32_t ba_ts_bitmap_31_0                                       : 32;
             uint32_t ba_ts_bitmap_63_32                                      : 32;
             uint32_t ba_ts_bitmap_95_64                                      : 32;
             uint32_t ba_ts_bitmap_127_96                                     : 32;
             uint32_t ba_ts_bitmap_159_128                                    : 32;
             uint32_t ba_ts_bitmap_191_160                                    : 32;
             uint32_t ba_ts_bitmap_223_192                                    : 32;
             uint32_t ba_ts_bitmap_255_224                                    : 32;
             uint32_t ba_ts_bitmap_287_256                                    : 32;
             uint32_t ba_ts_bitmap_319_288                                    : 32;
             uint32_t ba_ts_bitmap_351_320                                    : 32;
             uint32_t ba_ts_bitmap_383_352                                    : 32;
             uint32_t ba_ts_bitmap_415_384                                    : 32;
             uint32_t ba_ts_bitmap_447_416                                    : 32;
             uint32_t ba_ts_bitmap_479_448                                    : 32;
             uint32_t ba_ts_bitmap_511_480                                    : 32;
             uint32_t ba_ts_bitmap_543_512                                    : 32;
             uint32_t ba_ts_bitmap_575_544                                    : 32;
             uint32_t ba_ts_bitmap_607_576                                    : 32;
             uint32_t ba_ts_bitmap_639_608                                    : 32;
             uint32_t ba_ts_bitmap_671_640                                    : 32;
             uint32_t ba_ts_bitmap_703_672                                    : 32;
             uint32_t ba_ts_bitmap_735_704                                    : 32;
             uint32_t ba_ts_bitmap_767_736                                    : 32;
             uint32_t ba_ts_bitmap_799_768                                    : 32;
             uint32_t ba_ts_bitmap_831_800                                    : 32;
             uint32_t ba_ts_bitmap_863_832                                    : 32;
             uint32_t ba_ts_bitmap_895_864                                    : 32;
             uint32_t ba_ts_bitmap_927_896                                    : 32;
             uint32_t ba_ts_bitmap_959_928                                    : 32;
             uint32_t ba_ts_bitmap_991_960                                    : 32;
             uint32_t ba_ts_bitmap_1023_992                                   : 32;
#endif
};

#define RX_FRAME_1K_BITMAP_ACK_RESERVED_0A_OFFSET                                   0x0000000000000000
#define RX_FRAME_1K_BITMAP_ACK_RESERVED_0A_LSB                                      0
#define RX_FRAME_1K_BITMAP_ACK_RESERVED_0A_MSB                                      4
#define RX_FRAME_1K_BITMAP_ACK_RESERVED_0A_MASK                                     0x000000000000001f

#define RX_FRAME_1K_BITMAP_ACK_BA_BITMAP_SIZE_OFFSET                                0x0000000000000000
#define RX_FRAME_1K_BITMAP_ACK_BA_BITMAP_SIZE_LSB                                   5
#define RX_FRAME_1K_BITMAP_ACK_BA_BITMAP_SIZE_MSB                                   6
#define RX_FRAME_1K_BITMAP_ACK_BA_BITMAP_SIZE_MASK                                  0x0000000000000060

#define RX_FRAME_1K_BITMAP_ACK_GEN_MLO_NOTIFICATION_OFFSET                          0x0000000000000000
#define RX_FRAME_1K_BITMAP_ACK_GEN_MLO_NOTIFICATION_LSB                             7
#define RX_FRAME_1K_BITMAP_ACK_GEN_MLO_NOTIFICATION_MSB                             7
#define RX_FRAME_1K_BITMAP_ACK_GEN_MLO_NOTIFICATION_MASK                            0x0000000000000080

#define RX_FRAME_1K_BITMAP_ACK_RESERVED_0B_OFFSET                                   0x0000000000000000
#define RX_FRAME_1K_BITMAP_ACK_RESERVED_0B_LSB                                      8
#define RX_FRAME_1K_BITMAP_ACK_RESERVED_0B_MSB                                      9
#define RX_FRAME_1K_BITMAP_ACK_RESERVED_0B_MASK                                     0x0000000000000300

#define RX_FRAME_1K_BITMAP_ACK_BA_TID_OFFSET                                        0x0000000000000000
#define RX_FRAME_1K_BITMAP_ACK_BA_TID_LSB                                           10
#define RX_FRAME_1K_BITMAP_ACK_BA_TID_MSB                                           13
#define RX_FRAME_1K_BITMAP_ACK_BA_TID_MASK                                          0x0000000000003c00

#define RX_FRAME_1K_BITMAP_ACK_STA_FULL_AID_OFFSET                                  0x0000000000000000
#define RX_FRAME_1K_BITMAP_ACK_STA_FULL_AID_LSB                                     14
#define RX_FRAME_1K_BITMAP_ACK_STA_FULL_AID_MSB                                     26
#define RX_FRAME_1K_BITMAP_ACK_STA_FULL_AID_MASK                                    0x0000000007ffc000

#define RX_FRAME_1K_BITMAP_ACK_RESERVED_0C_OFFSET                                   0x0000000000000000
#define RX_FRAME_1K_BITMAP_ACK_RESERVED_0C_LSB                                      27
#define RX_FRAME_1K_BITMAP_ACK_RESERVED_0C_MSB                                      31
#define RX_FRAME_1K_BITMAP_ACK_RESERVED_0C_MASK                                     0x00000000f8000000

#define RX_FRAME_1K_BITMAP_ACK_MLO_STA_ID_OFFSET                                    0x0000000000000000
#define RX_FRAME_1K_BITMAP_ACK_MLO_STA_ID_LSB                                       32
#define RX_FRAME_1K_BITMAP_ACK_MLO_STA_ID_MSB                                       41
#define RX_FRAME_1K_BITMAP_ACK_MLO_STA_ID_MASK                                      0x000003ff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_SIZE_1024_ALLOWED_OFFSET                          0x0000000000000000
#define RX_FRAME_1K_BITMAP_ACK_BA_SIZE_1024_ALLOWED_LSB                             42
#define RX_FRAME_1K_BITMAP_ACK_BA_SIZE_1024_ALLOWED_MSB                             42
#define RX_FRAME_1K_BITMAP_ACK_BA_SIZE_1024_ALLOWED_MASK                            0x0000040000000000

#define RX_FRAME_1K_BITMAP_ACK_BA_SIZE_512_ALLOWED_OFFSET                           0x0000000000000000
#define RX_FRAME_1K_BITMAP_ACK_BA_SIZE_512_ALLOWED_LSB                              43
#define RX_FRAME_1K_BITMAP_ACK_BA_SIZE_512_ALLOWED_MSB                              43
#define RX_FRAME_1K_BITMAP_ACK_BA_SIZE_512_ALLOWED_MASK                             0x0000080000000000

#define RX_FRAME_1K_BITMAP_ACK_RESERVED_1A_OFFSET                                   0x0000000000000000
#define RX_FRAME_1K_BITMAP_ACK_RESERVED_1A_LSB                                      44
#define RX_FRAME_1K_BITMAP_ACK_RESERVED_1A_MSB                                      63
#define RX_FRAME_1K_BITMAP_ACK_RESERVED_1A_MASK                                     0xfffff00000000000

#define RX_FRAME_1K_BITMAP_ACK_ADDR1_31_0_OFFSET                                    0x0000000000000008
#define RX_FRAME_1K_BITMAP_ACK_ADDR1_31_0_LSB                                       0
#define RX_FRAME_1K_BITMAP_ACK_ADDR1_31_0_MSB                                       31
#define RX_FRAME_1K_BITMAP_ACK_ADDR1_31_0_MASK                                      0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_ADDR1_47_32_OFFSET                                   0x0000000000000008
#define RX_FRAME_1K_BITMAP_ACK_ADDR1_47_32_LSB                                      32
#define RX_FRAME_1K_BITMAP_ACK_ADDR1_47_32_MSB                                      47
#define RX_FRAME_1K_BITMAP_ACK_ADDR1_47_32_MASK                                     0x0000ffff00000000

#define RX_FRAME_1K_BITMAP_ACK_ADDR2_15_0_OFFSET                                    0x0000000000000008
#define RX_FRAME_1K_BITMAP_ACK_ADDR2_15_0_LSB                                       48
#define RX_FRAME_1K_BITMAP_ACK_ADDR2_15_0_MSB                                       63
#define RX_FRAME_1K_BITMAP_ACK_ADDR2_15_0_MASK                                      0xffff000000000000

#define RX_FRAME_1K_BITMAP_ACK_ADDR2_47_16_OFFSET                                   0x0000000000000010
#define RX_FRAME_1K_BITMAP_ACK_ADDR2_47_16_LSB                                      0
#define RX_FRAME_1K_BITMAP_ACK_ADDR2_47_16_MSB                                      31
#define RX_FRAME_1K_BITMAP_ACK_ADDR2_47_16_MASK                                     0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_CTRL_OFFSET                                    0x0000000000000010
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_CTRL_LSB                                       32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_CTRL_MSB                                       47
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_CTRL_MASK                                      0x0000ffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_SEQ_OFFSET                                     0x0000000000000010
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_SEQ_LSB                                        48
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_SEQ_MSB                                        63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_SEQ_MASK                                       0xffff000000000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_31_0_OFFSET                             0x0000000000000018
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_31_0_LSB                                0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_31_0_MSB                                31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_31_0_MASK                               0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_63_32_OFFSET                            0x0000000000000018
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_63_32_LSB                               32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_63_32_MSB                               63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_63_32_MASK                              0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_95_64_OFFSET                            0x0000000000000020
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_95_64_LSB                               0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_95_64_MSB                               31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_95_64_MASK                              0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_127_96_OFFSET                           0x0000000000000020
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_127_96_LSB                              32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_127_96_MSB                              63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_127_96_MASK                             0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_159_128_OFFSET                          0x0000000000000028
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_159_128_LSB                             0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_159_128_MSB                             31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_159_128_MASK                            0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_191_160_OFFSET                          0x0000000000000028
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_191_160_LSB                             32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_191_160_MSB                             63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_191_160_MASK                            0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_223_192_OFFSET                          0x0000000000000030
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_223_192_LSB                             0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_223_192_MSB                             31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_223_192_MASK                            0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_255_224_OFFSET                          0x0000000000000030
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_255_224_LSB                             32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_255_224_MSB                             63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_255_224_MASK                            0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_287_256_OFFSET                          0x0000000000000038
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_287_256_LSB                             0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_287_256_MSB                             31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_287_256_MASK                            0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_319_288_OFFSET                          0x0000000000000038
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_319_288_LSB                             32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_319_288_MSB                             63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_319_288_MASK                            0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_351_320_OFFSET                          0x0000000000000040
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_351_320_LSB                             0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_351_320_MSB                             31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_351_320_MASK                            0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_383_352_OFFSET                          0x0000000000000040
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_383_352_LSB                             32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_383_352_MSB                             63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_383_352_MASK                            0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_415_384_OFFSET                          0x0000000000000048
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_415_384_LSB                             0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_415_384_MSB                             31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_415_384_MASK                            0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_447_416_OFFSET                          0x0000000000000048
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_447_416_LSB                             32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_447_416_MSB                             63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_447_416_MASK                            0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_479_448_OFFSET                          0x0000000000000050
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_479_448_LSB                             0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_479_448_MSB                             31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_479_448_MASK                            0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_511_480_OFFSET                          0x0000000000000050
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_511_480_LSB                             32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_511_480_MSB                             63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_511_480_MASK                            0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_543_512_OFFSET                          0x0000000000000058
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_543_512_LSB                             0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_543_512_MSB                             31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_543_512_MASK                            0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_575_544_OFFSET                          0x0000000000000058
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_575_544_LSB                             32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_575_544_MSB                             63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_575_544_MASK                            0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_607_576_OFFSET                          0x0000000000000060
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_607_576_LSB                             0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_607_576_MSB                             31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_607_576_MASK                            0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_639_608_OFFSET                          0x0000000000000060
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_639_608_LSB                             32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_639_608_MSB                             63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_639_608_MASK                            0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_671_640_OFFSET                          0x0000000000000068
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_671_640_LSB                             0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_671_640_MSB                             31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_671_640_MASK                            0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_703_672_OFFSET                          0x0000000000000068
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_703_672_LSB                             32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_703_672_MSB                             63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_703_672_MASK                            0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_735_704_OFFSET                          0x0000000000000070
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_735_704_LSB                             0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_735_704_MSB                             31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_735_704_MASK                            0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_767_736_OFFSET                          0x0000000000000070
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_767_736_LSB                             32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_767_736_MSB                             63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_767_736_MASK                            0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_799_768_OFFSET                          0x0000000000000078
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_799_768_LSB                             0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_799_768_MSB                             31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_799_768_MASK                            0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_831_800_OFFSET                          0x0000000000000078
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_831_800_LSB                             32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_831_800_MSB                             63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_831_800_MASK                            0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_863_832_OFFSET                          0x0000000000000080
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_863_832_LSB                             0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_863_832_MSB                             31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_863_832_MASK                            0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_895_864_OFFSET                          0x0000000000000080
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_895_864_LSB                             32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_895_864_MSB                             63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_895_864_MASK                            0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_927_896_OFFSET                          0x0000000000000088
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_927_896_LSB                             0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_927_896_MSB                             31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_927_896_MASK                            0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_959_928_OFFSET                          0x0000000000000088
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_959_928_LSB                             32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_959_928_MSB                             63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_959_928_MASK                            0xffffffff00000000

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_991_960_OFFSET                          0x0000000000000090
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_991_960_LSB                             0
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_991_960_MSB                             31
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_991_960_MASK                            0x00000000ffffffff

#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_1023_992_OFFSET                         0x0000000000000090
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_1023_992_LSB                            32
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_1023_992_MSB                            63
#define RX_FRAME_1K_BITMAP_ACK_BA_TS_BITMAP_1023_992_MASK                           0xffffffff00000000

#endif
